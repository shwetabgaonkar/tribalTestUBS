import {
	FETCH_PRODUCT_DATA, 
	FETCH_CART_DATA, 
	ADD_TO_CART_SUCCESS, 
	DELETE_CART_PRODUCT_SUCCESS,
	UNLOAD_ADD_TO_CART,
	UNLOAD_DELETE_TO_CART
} from '../actions/actions';

const initialState = {
	productData:undefined,
	cartData:undefined,
	addToCartSuccess:undefined,
	deleteCartProduct:undefined
}

const handlers = {
  [FETCH_PRODUCT_DATA]: (_,action) =>({
    productData: action.data
  }),
  [FETCH_CART_DATA]: (_,action) =>({
    cartData: action.data
  }),
  [ADD_TO_CART_SUCCESS]: (_,action) =>({
    addToCartSuccess: action.data
  }),
  [DELETE_CART_PRODUCT_SUCCESS]: (_,action) =>({
    deleteCartProduct: action.data
  }),
  [UNLOAD_ADD_TO_CART]: () =>({
    addToCartSuccess: undefined
  }),
  [UNLOAD_DELETE_TO_CART]: () =>({
    deleteCartProduct: undefined
  })
}

export default function dataReducer (state = initialState, action) {
  const handler = handlers[action.type];
  if (!handler) {
    return state;
  }
  return { ...state, ...handler(state, action) };
}