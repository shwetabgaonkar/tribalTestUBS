import React, {Fragment} from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './components/App';
import ProductDetails from './components/ProductDetails';
import Cart from './components/Cart';
import Header from './components/Header';
import Footer from './components/Footer';
import * as serviceWorker from './serviceWorker';
import {combineReducers} from 'redux';
import data from './reducers/reducer';
import {createStore, applyMiddleware} from 'redux';
import thunk from 'redux-thunk';
import { Provider } from 'react-redux';
import { Route, BrowserRouter as Router } from 'react-router-dom';

const rootReducer = combineReducers({data});

const store = createStore(rootReducer, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__(), applyMiddleware(thunk));

const routing = (
    <Route>
	    <Route path="/" >
	      <Route>
	        <Route path="/" component={App} />
			<Route path="/product" component={ProductDetails} />
			<Route path="/cart" component={Cart} />
	      </Route>
	    </Route>
	</Route>
);

const tribalUI = (
  <Router>
    <Header/>
	<div class="row">	  
	  {routing}
	  <Footer/>
	</div>
  </Router>
);


ReactDOM.render(<Provider store={store}>{tribalUI}</Provider>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
