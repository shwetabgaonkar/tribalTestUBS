import React, {Component} from 'react';
import {connect} from 'react-redux';
import productImage from '../img/product-image-small.jpg';
import axios from 'axios';
import {deleteCartProduct} from '../actions/actions';

class ProductCartRow extends Component {
  constructor() {
    super();
	this.onDelete = this.onDelete.bind(this);
  }
  
  onDelete() {
	const {productData} = this.props;
	this.props.dispatch(deleteCartProduct(productData.id));
	this.props.clearCartInterval();
  }
  
  
  
  render() {
	const {productData} = this.props;
    return(
		<div className="productRow productRowBorder overflowHide">
		  <div className="col-5">
			<img src={productImage} style={{"width":"85%"}} />
		  </div>
		  <div className="col-l-2 detailsPanel overflowHide">
			<div className="floatLeft">
				<a><h3>{productData.productName}</h3></a>
				<p className="productDesc">The most advanced PlayStation® system ever now comes in a bundle that includes a jet black 1TB PS4™ Pro system, a matching</p>
				<p style={{"line-height": "32px"}}>In stock</p>
				<p>Qty: 1</p>
				 <p className="breadCrums" style={{"line-height": "32px"}}><a className="cursorPointer" onClick={this.onDelete.bind(this)}>Delete</a> | <a>Save for later</a> | <a>See more like this</a></p>
			</div>
			<div className="floatRight"><h3>&pound;{productData.price.toFixed(2)}</h3></div>
		  </div>
	    </div>
    );
  }
}

export default connect()(ProductCartRow);