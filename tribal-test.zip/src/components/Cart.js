import React, {Component} from 'react';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import productImage from '../img/product-image-small.jpg';
import ProductSmallTile from './ProductSmallTile';
import ProductCartRow from './ProductCartRow';
import axios from 'axios';
import {fetchCartData, unloadDeleteToCart} from '../actions/actions';

class Cart extends Component {
  constructor() {
    super();
	this.getCartTotal = this.getCartTotal.bind(this);
	this.getProductCartRow = this.getProductCartRow.bind(this);
	this.state={
		cartData:undefined
	}
	this.setCartInterval='';
  }
  
  componentDidMount() {
    this.props.dispatch(fetchCartData());
  }
  
  componentWillReceiveProps(props) { 
    if(props.data) {
      this.setState({cartData: props.data});
    }
	if(props.deleteCartProduct) {
	  this.setCartInterval = setInterval(() => {
		this.props.dispatch(fetchCartData());
	  },7000);	  
	  this.props.dispatch(unloadDeleteToCart());
	}
  }
  
  componentUnmount(){
	clearInterval(this.setCartInterval);
  }
  
  getCartTotal() {
	const {cartData} = this.state;
	let catTotal = cartData.reduce(function(prev, cur) {
	  return prev + cur.price;
	}, 0);
	return catTotal;
  }
  
  clearCartInterval() {
	clearInterval(this.setCartInterval);
  }  
  
  getProductCartRow() {
	const {cartData} = this.state;
	let cartProducts = [];
	if(cartData.length > 0) {
	  cartData.map(item => {
		cartProducts.push(<ProductCartRow key={item.id} productData={item} clearCartInterval={this.clearCartInterval}/>)
	  })
	}
	return cartProducts;
  }
  
  render() {
	const {cartData} = this.state;
	if(cartData) {
		return(
			<div id='cart'>
			  <div className="detailsPanel overflowHide">
				  <h2>Shopping cart</h2>
				  {cartData.length === 0 && <div><h5>Your cart is empty.</h5></div>}
				  {this.getProductCartRow()}				  
				  <div className="floatRight"><h3>Subtotal ({cartData.length} items): &pound;{this.getCartTotal().toFixed(2)}</h3></div>	  
			  </div>
			  <div className="productList overflowHide alignTextCenter space-below">
				  <ProductSmallTile />
				  <ProductSmallTile />
				  <ProductSmallTile />
				  <ProductSmallTile />
				  <ProductSmallTile />	  
			  </div>
			</div>
		);    
	} else {
		return (<div><h2>Loading...</h2></div>);
	}
	
  }
}

Cart.propTypes = {
  data: PropTypes.array
};

function mapStateToProps(state) {
  return {
    data: state.data.cartData,
	deleteCartProduct:state.data.deleteCartProduct
  };
}
export default connect(mapStateToProps)(Cart);