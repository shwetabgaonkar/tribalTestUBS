import React, {Component, Fragment} from 'react';
import visaCard from '../img/visaCard.jpg';
import masterCard from '../img/masterCard.jpg';
import paypalCard from '../img/payPal.jpg';
import amerExpressCard from '../img/amerExprCard.jpg';

export default class Footer extends Component {
  constructor() {
    super();
  }
  
  render() {
    return(
		<Fragment>
		  <div className="breadCrumLinks overflowHide sub-text">
			<div className="col-4 alignMent alignTextCenter"><i className="fa fa-heart" style={{"font-size":"24px"}}></i><span className="space-between">Lorem ipsum</span></div>
			<div className="col-4 alignMent alignTextCenter"><i className="fa fa-bell" style={{"font-size":"24px"}}></i><span className="space-between">Lorem ipsum</span></div>
			<div className="col-4 alignMent alignTextCenter withPrice"><p>Lorem ipsum</p><p style={{"font-size":"25px", "font-face":"bold"}}>&pound;120.00</p></div>
			<div className="col-4 alignMent alignTextCenter"><p>Lorem ipsum</p><div><img src={visaCard} /><img src={masterCard} className="space-between"/><img src={paypalCard} className="space-between"/><img src={amerExpressCard} className="space-between"/></div></div>
		  </div>
		  <footer className="overflowHide sub-text">
			<div className="col-5 alignTextCenter paddingTopBottom">LOREM IPSUM</div>
			<div className="col-5 alignTextCenter paddingTopBottom selected">LOREM IPSUM</div>
			<div className="col-5 alignTextCenter paddingTopBottom">LOREM IPSUM</div>
			<div className="col-5 alignTextCenter paddingTopBottom">LOREM IPSUM</div>
			<div className="col-5 alignTextCenter paddingTopBottom">LOREM IPSUM</div>
		  </footer>
		</Fragment>
	);
  }
}