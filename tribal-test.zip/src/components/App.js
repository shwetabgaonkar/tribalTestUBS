import React from 'react';
import { Redirect } from 'react-router'

function App() {
  return <Redirect to='/product'/>;
}

export default App;