import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import logo from '../img/logo.png';
import { Link } from 'react-router-dom';
import {fetchCartData} from '../actions/actions';

class Header extends Component {
  constructor() {
    super();
	this.state={
	  cartData:undefined
	}
  }
  
  componentDidMount() {
    this.props.dispatch(fetchCartData());
  }  
  
  componentWillReceiveProps(props) { 
    if(props.data) {
      this.setState({cartData: props.data});
    }
  }
  
  getCartTotal() {
	const {cartData} = this.state;
	let catTotal = cartData.reduce(function(prev, cur) {
	  return prev + cur.price;
	}, 0);
	return catTotal;
  }
  
  render() {
	const {cartData} = this.state;
	if(cartData) {
		const cartTotal = this.getCartTotal();
		return(
			<header className="overflowHide">
			  <div className="brand-logo floatLeft"><img src={logo} alt="Play Station" width="80" height="auto" /></div>
			  <div className="cart-options">
				<Link to='/cart'><i className="fa fa-shopping-cart cursorPointer"><div className="circle alignTextCenter">{cartData.length}</div></i></Link>
				<div className="cart-price" style={{"margin-left":"10px"}}>&pound;{cartTotal}</div>
				<i className="fa fa-heart space-between cursorPointer"><div className="circle alignTextCenter">2</div></i>
			  </div>
			</header>
		);
	} else {
		return(
			<header className="overflowHide">
			  <div className="brand-logo floatLeft"><img src={logo} alt="Play Station" width="80" height="auto" /></div>			  
			</header>
		);
	}
	
  }
}

Header.propTypes = {
  data: PropTypes.array
};

function mapStateToProps(state) {
  return {
    data: state.data.cartData
  };
}
export default connect(mapStateToProps)(Header);