/* eslint-disable import/no-unresolved */
export { unstable_batchedUpdates } from 'react-dom'
